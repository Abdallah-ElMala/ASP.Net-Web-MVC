﻿using assignment02.Models;

namespace assignment02.viewmodel
{
    public class studentviewmodel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public int? deptid { get; set; }

        public List<Department>? Deptlist { get; set; }

    }
}
