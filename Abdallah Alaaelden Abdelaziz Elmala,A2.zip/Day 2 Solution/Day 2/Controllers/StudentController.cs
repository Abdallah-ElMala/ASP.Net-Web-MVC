﻿using Day_2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace Day_2.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Index()
        {
            StudentBL students = new StudentBL();
            List<Student> stu = students.GetAll();

            return View("index", stu);
        }

        public IActionResult Details(int id)
        {
            StudentBL students = new StudentBL();
            Student students2 = students.getbyid(id);

            return View("Details", students2);
        }
    }
}
