﻿using Day_2.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;


namespace Day_2.Data.ConfigrationClasses
{
    public class StuCrsResConfigrations : IEntityTypeConfiguration<StuCrsRes>
    {
        public void Configure(EntityTypeBuilder<StuCrsRes> builder)
        {
            builder.HasKey(scr => new { scr.StudentId, scr.CourseId });
        }
    }
}
