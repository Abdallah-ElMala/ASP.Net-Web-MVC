﻿using Day_2.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Day_2.Data.ConfigrationClasses
{
    public class TeacherConfigrations : IEntityTypeConfiguration<Teacher>
    {
        public void Configure(EntityTypeBuilder<Teacher> builder)
        {
            builder.Property(p => p.salary)
               .HasColumnType("decimal(18, 2)");

            builder.HasOne(d => d.tchcourse)
                       .WithMany(s => s.crsteacher)
                       .HasForeignKey(p => p.courseid)
                       .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
