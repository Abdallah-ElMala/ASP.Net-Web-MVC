﻿using Day_2.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Day_2.Data.ConfigrationClasses
{
    public class DepartmentConfigrations : IEntityTypeConfiguration<Department>
    {
        public void Configure(EntityTypeBuilder<Department> builder)
        {
            builder.Property(scr => scr.Name)
        .HasMaxLength(50);

            builder.HasMany(d => d.courses)
                       .WithOne(s => s.crsdept)
                       .HasForeignKey(p => p.deptid)
                       .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(d => d.teachrs)
                  .WithOne(s => s.tchdept)
                  .HasForeignKey(p => p.deptid)
                  .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(d => d.students)
                  .WithOne(s => s.studept)
                  .HasForeignKey(p => p.deptid)
                  .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
