﻿using Day_2.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Day_2.Data.ConfigrationClasses
{
    public class CourseConfigrations : IEntityTypeConfiguration<Course>
    {
        public void Configure(EntityTypeBuilder<Course> builder)
        {
            builder.Property(scr => scr.Name)
                    .HasMaxLength(50);

            builder.HasMany(d => d.crstudent)
                       .WithOne(s => s.crsid)
                       .HasForeignKey(p => p.CourseId)
                       .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
