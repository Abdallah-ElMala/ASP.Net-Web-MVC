﻿namespace Day_2.Models
{
    public class StuCrsRes
    {
        public int StudentId { get; set; }
        public int CourseId { get; set; }
        public double Grade { get; set; }


        public Student? stuid { get; set; }
        public Course? crsid { get; set; }
    }
}
