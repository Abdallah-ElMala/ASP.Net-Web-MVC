﻿namespace Day_2.Models
{
    public class Course
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Degree { get; set; }
        public int MinDegree { get; set; }
        public int deptid { get; set; }

        public List<StuCrsRes> crstudent { get; set; }
        public Department crsdept { get; set; }
        public List<Teacher> crsteacher { get; set; }
    }
}
