﻿namespace Day_2.Models
{
    public class Department 
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string mgrname { get; set; }

        public List<Student> students { get; set; }
        public List<Course> courses { get; set; }
        public List<Teacher> teachrs { get; set; }
    }
}
