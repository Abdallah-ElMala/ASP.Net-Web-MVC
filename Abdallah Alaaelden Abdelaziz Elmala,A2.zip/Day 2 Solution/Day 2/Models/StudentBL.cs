﻿using Day_2.Data;
using Microsoft.EntityFrameworkCore;

namespace Day_2.Models
{
    public class StudentBL
    {
        DigitalDbContext context = new DigitalDbContext();

        public List<Student> GetAll()
        {
            return context.Students
                          .Include(s => s.studept)
                          .Include(b => b.stucourse)
                          .ToList();
        }
        public Student getbyid(int id)
        {
            return context.Students
                          .FirstOrDefault(E => E.Id == id);
        }
    }
}
