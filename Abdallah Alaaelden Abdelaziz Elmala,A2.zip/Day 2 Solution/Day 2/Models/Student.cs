﻿namespace Day_2.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public int deptid { get; set; }

        public List<StuCrsRes> stucourse { get; set; }
        public Department studept { get; set; }
    }
}
