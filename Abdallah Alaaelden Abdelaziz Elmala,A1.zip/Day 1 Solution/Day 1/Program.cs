using Microsoft.AspNetCore.Mvc;

namespace Day_1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
            }
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");
            app.Run();

    }
        /// ////////////////////////////////////////////////////////////////////////
            public IActionResult ShowMessage()
        {
            return Content("Hello!");
        }

        private IActionResult Content(string v)
        {
            throw new NotImplementedException();
        }
        public IActionResult ShowMix(int id)
        {
            if (id % 2 == 0)
            {
                return View("View1"); 
            }
            return Content($"Odd ID: {id}"); 
        }

        private IActionResult View(string v)
        {
            throw new NotImplementedException();
        }
    }
}
