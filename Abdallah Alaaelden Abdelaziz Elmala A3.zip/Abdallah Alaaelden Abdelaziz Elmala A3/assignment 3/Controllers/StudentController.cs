﻿using System;
using assignment02.Data.DigitalDBcontext;
using assignment02.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace assignment02.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Index()
        {
            studentBL students = new studentBL();
            List<student> stu = students.GetAll();

            return View("index", stu);
        }

        public IActionResult Details(int id)
        {
            studentBL students = new studentBL();
            student students2 = students.getbyid(id);

             return View("Details",students2);
        }
       

    }
}
