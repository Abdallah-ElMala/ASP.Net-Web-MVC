﻿using assignment02.Data.DigitalDBcontext;
using Microsoft.EntityFrameworkCore;

namespace assignment02.Models
{
    public class studentBL
    {
        DigitalDBContexts context = new DigitalDBContexts();

        public List<student> GetAll()
        {
            return context.students
                          .Include(s=>s.studept)
                          .Include(b=>b.stucourse)
                          .ToList();
        }
        public student getbyid(int id)
        {
            return context.students
                          .FirstOrDefault(E => E.Id == id);
        }



    }
}
